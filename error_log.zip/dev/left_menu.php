<div id="msc-layer-placeholder-wrapper" style="width:6%;  vertical-align: top; display: inline-block; background: linear-gradient(to top, #4caf50 0%, #5c9ae4 100%);color: #efefef; height: 100%; padding: 5px;box-shadow: inset -3px 0px 5px 1px rgb(0 0 0 / 20%);margin-top: -50px;">

  <div style="text-align:center;margin: 25% 10%;">
	<div class="left_bar_icon_div" id="left_bar_icon_template">
		<i class="fas fa-th-large" 
		   style="position: absolute; top: 50%; transform: translateY(-50%); left: 30%;"></i>
	</div>
	<p style="font-size: 10px;margin-bottom: 0px;word-break: break-word;font-weight: 600;">Template</p>
  </div>
  
  <div style="text-align:center;margin: 25% 15%;">
	<div class="left_bar_icon_div" id="left_bar_icon_music">
		<i class="fa fa-music" aria-hidden="true" 
		   style="position: absolute; top: 50%; transform: translateY(-50%); left: 30%;"></i>
	</div>
	<p style="font-size: 10px;margin-bottom: 0px;font-weight: 600;">Music</p>
  </div>
  
  <div style="text-align:center;margin: 25% 15%;">
	<div class="left_bar_icon_div" id="left_bar_icon_video">
		<i class="fa fa-video-camera" aria-hidden="true" 
		   style="position: absolute; top: 50%; transform: translateY(-50%); left: 30%;"></i>
	</div>
	<p style="font-size: 10px;margin-bottom: 0px;font-weight: 600;">Videos</p>
  </div>
  
  <div style="text-align:center;margin: 25% 15%;">
	<div class="left_bar_icon_div" id="left_bar_icon_image">
		<i class="fa fa-picture-o" aria-hidden="true" 
		   style="position: absolute; top: 50%; transform: translateY(-50%); left: 30%;"></i>
	</div>
	<p style="font-size: 10px;margin-bottom: 0px;font-weight: 600;">Images</p>
  </div>
  
  <div style="text-align:center;margin: 25% 15%;">
	<div class="left_bar_icon_div" id="left_bar_icon_bg">
		<i class="fa fa-star-half-o" aria-hidden="true" 
		   style="position: absolute; top: 50%; transform: translateY(-50%); left: 30%;"></i>
	</div>
	<p style="font-size: 10px;margin-bottom: 0px;word-break: break-word;font-weight: 600;">BG Imgs</p>
  </div>
  
  <div style="text-align:center;margin: 25% 15%;">
	<div class="left_bar_icon_div" id="left_bar_icon_font">
		<i class="fa fa-font" aria-hidden="true" 
		   style="position: absolute; top: 50%; transform: translateY(-50%); left: 30%;"></i>
	</div>
	<p style="font-size: 10px;margin-bottom: 0px;word-break: break-word;font-weight: 600;">Text</p>
  </div>
   
  <div style="text-align:center;margin: 25% 15%;">
	<div class="left_bar_icon_div" id="left_bar_icon_shape">
		<i class="fa fa-square-o" aria-hidden="true"
		   style="position: absolute; top: 50%; transform: translateY(-50%); left: 30%;"></i>
	</div>
	<p style="font-size: 10px;margin-bottom: 0px;word-break: break-word;font-weight: 600;">Shapes</p>
  </div>
  
</div>